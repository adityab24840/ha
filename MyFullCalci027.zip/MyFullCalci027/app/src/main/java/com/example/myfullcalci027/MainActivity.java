package com.example.myfullcalci027;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    boolean isNewOp = true;
    EditText result;
    String op1 = "";
    String op2 = "";
    String op = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = findViewById(R.id.result);
    }

    public void numberEvent(View view){
        if(isNewOp)
            result.setText("");
        isNewOp = false;
        String number = result.getText().toString();

        switch (view.getId()) {
            case R.id.r4b1:
                number += "1";
                break;
            case R.id.r4b2:
                number += "2";
                break;
            case R.id.r4b3:
                number += "3";
                break;
            case R.id.r3b1:
                number += "4";
                break;
            case R.id.r3b2:
                number += "5";
                break;
            case R.id.r3b3:
                number += "6";
                break;
            case R.id.r2b1:
                number += "7";
                break;
            case R.id.r2b2:
                number += "8";
                break;
            case R.id.r2b3:
                number += "9";
                break;
            case R.id.r5b1:
                number += "0";
                break;
            case R.id.r5b2:
                number += ".";
                break;
            case R.id.plusminus:
                number = "-" + number;
                break;
        }

        result.setText(number);
    }

    public void operatorEvent(View view) {
        isNewOp=true;
        op1 = result.getText().toString();
        switch (view.getId()) {
            case R.id.add: op = "+"; break;
            case R.id.sub: op = "-"; break;
            case R.id.mul: op = "*"; break;
            case R.id.divide: op = "/"; break;
        }
    }

    public void equalEvent(View view){
        op2 = result.getText().toString();
        double ans = 0.0;
        switch(op) {
            case "+":
                ans = Double.parseDouble(op1) + Double.parseDouble(op2);
                break;
            case "-":
                ans = Double.parseDouble(op1) - Double.parseDouble(op2);
                break;
            case "*":
                ans = Double.parseDouble(op1) * Double.parseDouble(op2);
                break;
            case "/":
                ans = Double.parseDouble(op1) / Double.parseDouble(op2);
                break;
        }
        result.setText( ans + "");
    }

    public void acEvent(View view) {
        result.setText("0");
        isNewOp = true;
    }

    public void percentEvent(View view) {
        double no = Double.parseDouble(result.getText().toString())/100;
        result.setText(no + "");
        isNewOp = true;
    }


}